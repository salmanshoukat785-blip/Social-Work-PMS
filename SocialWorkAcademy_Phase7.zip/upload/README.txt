Put the project zip (for example SocialWorkAcademy_Phase2.zip) in this folder.
GitHub Actions will unpack it, build the app and publish the APK
under Actions -> latest run -> Artifacts.
